<?php
	require_once "view/header.php";
?>

	<main>

		<center>
	<div id="imgindex">
		<div id="imglog">
			<p><br>>>Fasilitas &amp; Layanan Kamar<br>&nbsp;</p>
		</div>
	</div>

			<div id="fas1">
				<h3>Fasiltas</h3><br>
				<p>
					Layanan Kamar, Massage, Parking Area, Cleaning service, <br>Rental cycle, Morning Call
				</p>
			</div>

			<div id="fas2">
				<h3>Internet dan Wifi</h3><br>
				<p>
					Koneksi LAN, Koneksi internet gratis
				</p>
			</div>

			<div id="fas3">
				<h3>Kamar</h3><br>
				<p>
					Bath and Toilet, Toothbrush / Toothpastem, Soap, <br>Sandal, Shower cap, Comb, Shower, Air conditioner, <br>Refrigerator, Bath towel, Hair Conditioner, Hair Dryer, <br>Cottonbud, Mini Bar, Safety box, Face towel, <br>Hand towel, Shampoo, Body soap, Shower Toilet
				</p>
			</div>

<?php
	require_once "view/footer.php"
?>