# Sistem Informasi
Sistem Informasi Pemesanan Kamar Hotel Menggunakan PHP dan MySQL

Web Server : Xampp (Apache) 5.6.8
PHP : 5.5
DB : MySQL (koneksi PDO)
Library : - SweetAlert (Javascript) - FPDF (Laporan)

# Login Admin
  user & pass : admin
# Login User
  user: ali 
  pass: 123

# SS
![sihotel1](https://github.com/user-attachments/assets/b4163420-88ad-4da7-a3d8-a69b15fdac2c)

![sihotel2](https://github.com/user-attachments/assets/97acecc8-291e-4028-bee2-0e3adc3e1fa5)

![sihotel3](https://github.com/user-attachments/assets/4d45dc19-9000-4c81-ba59-4b62487fad42)

