<?php
	require_once "view/header.php";
?>

	<aside>
		<div id="abc">
			<p>Selamat Datang di Beranda Admin</p>
		</div>

		<div class="kotak"><img src="../gambar/Superior.jpg" width="100%" height="100%"></div>
		<div class="kotak"><img src="../gambar/Presidential.jpg" width="100%" height="100%"></div>
		<div class="kotak"><img src="../gambar/Deluxe.jpg" width="100%" height="100%"></div>
		<div class="kotak"><img src="../gambar/Ruang-Konferensi.jpg" width="100%" height="100%"></div>
		<div class="kotak"><img src="../gambar/Ruang-Konferensi2.jpg" width="100%" height="100%"></div>
		<div class="kotak"><img src="../gambar/Restoran.jpg" width="100%" height="100%"></div>
	</aside>

<?php
	require_once "view/footer.php"
?>